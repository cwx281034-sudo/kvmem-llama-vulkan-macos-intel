# KVMem Vulkan Fix Validation

- Vulkan CLI: `llama-kvmem-cli --kvmem --device Vulkan0 ... -n 8` completed without SIGSEGV and generated `Hello my name is John`.
- CTest: 19 tests discovered; 18 passed and 1 skipped (`kvmem-mtp-kv-test`, CUDA-only).
- Rebuilt: `llama-kvmem-cli` and `llama-kvmem-server` in Vulkan builds.
