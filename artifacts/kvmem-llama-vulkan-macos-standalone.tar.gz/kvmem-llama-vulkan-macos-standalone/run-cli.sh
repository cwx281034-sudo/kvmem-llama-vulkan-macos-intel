#!/bin/bash
set -e
ROOT="$(cd "$(dirname "$0")" && pwd)"
export GGML_VK_VISIBLE_DEVICES="${GGML_VK_VISIBLE_DEVICES:-0}"
exec "$ROOT/bin/llama-kvmem-cli" "$@"
